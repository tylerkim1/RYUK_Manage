import React from 'react'

const SIgn_img = () => {
    return (
        <>
            <div className="right_data mt-5" style={{ width: "100%" }}>
                <div className="sign_img mt-5">
                    <img className = "neetcompany" style={{ maxWidth: 400 }} alt="" src="image/neetcompany1.png"/>
                </div>
            </div>
        </>
    )
}

export default SIgn_img