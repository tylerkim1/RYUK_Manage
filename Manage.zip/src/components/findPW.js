import '../App.css';
import React, { useState } from 'react'


const findPW = () => {
  return (
    <div>
      <text>
        Hello world!
      </text>
    </div>
  );
}

export default findPW;